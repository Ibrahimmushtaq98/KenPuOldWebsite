public class Course {
    public Course(String name) throws Exception {
        return;
    }

    public String find(String number) {
        return null;
    }

    public void enroll(String name, String number) throws Exception {
        return;
    }

    public void print() {
        return;
    }

}
