public class Student {
    public Student(String name, String number) throws Exception {
        return;
    }

    public void print() {
        return;
    }

    public String getNumber() {
        return null;
    }

    public String getName() {
        return null;
    }
}
