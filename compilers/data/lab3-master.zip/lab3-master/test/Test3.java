class Empty {
}
