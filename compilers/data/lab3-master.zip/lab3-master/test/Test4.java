/* A hello class */
class Hello {
    public Hello(int name) {




    }
}
