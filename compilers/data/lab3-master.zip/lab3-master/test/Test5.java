class Hello {
    String say(String message) {
        return "Hello there, " + message;
    }

    int adder(int a, int b) {
        return a + b;
    }
}
