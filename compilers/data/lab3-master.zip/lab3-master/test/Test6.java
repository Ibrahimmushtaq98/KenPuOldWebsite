public class Hello {
    String name;
    public Hello(name) {
        this.name = name;
    }
    @Override
    String toString() {
        return this.name;
    }
}
