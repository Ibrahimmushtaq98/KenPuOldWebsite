import java.util.*;

public class FSM {
    public FSM() {
        // To be completed
    }

    public void add(int source, int target, String label) {
        // To be completed
    }

    public void initState(int state) {
        // To be completed
    }

    public void finalState(int state) {
        // To be completed
    }

    public Set<Integer> reachable(String input) {
        // To be completed
        return null;
    }

    public boolean accept(String input) {
        // To be completed
        return false;
    }

    public String matchLongest(String input) {
        // To be completed
        return null;
    }

    public void print() {
        // To be completed
    }


    public static FSM ID() {
        // To be completed
        return null;
    }

    public static FSM Whitespace() {
        // To be completed
        return null;
    }
}
