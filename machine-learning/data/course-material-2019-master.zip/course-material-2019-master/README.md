# Machine Learning, Fall 2019

## Quizzes

1. 2019-09-23: On Tensors https://forms.gle/uBqWGanPfsnQMZJ26
2. 2019-09-25: On Linear Algebra https://forms.gle/g1TZTYTRp4ydQ9sv9
3. 2019-10-29: On Tensorflow basics: https://forms.gle/3xDV6qCPvBPdjmXH9  **Single attempt only**
4. 2019-10-30: On regression models: https://forms.gle/CsPpGuEUarucQ8517  **Single attempt only**

## Colaboratory notebooks

The shared folder is found here:
https://drive.google.com/drive/folders/1tHdPFwHk90q3YWMqcJaKVjPOOz9BU1tY?usp=sharing

## Assignments

| Assignment | Due Date | URL |
|------------|----------|-----|
| A1: Iris Classficiation | October 27, 2019 | https://classroom.github.com/a/x4sPGDIr |
| A2: MNIST Classificaion with three models | November 17, 2019 | https://classroom.github.com/a/ymsWDus2 |
| A3: Weather event prediction | December 8, 2019 | https://classroom.github.com/a/l3jupRUU |
