(ns b.math)

(def PI 3.1415)
(defn add [x y] (+ x y))
(defn sub [x y] (- x y))
(defn area-of-a-circle [r] (* PI r r))

