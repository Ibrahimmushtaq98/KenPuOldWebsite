Issues:

- Clojure kernel pollutes the output
